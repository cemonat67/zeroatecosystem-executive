# Zero@ UI Standard v1

Color Hierarchy

Primary background
#02154e

Accent
#f9ba00

Text
#e6edf6

Card border
rgba(255,255,255,0.12)

Interaction

hover glow
orange highlight
minimal animation

Typography

Executive readable
no playful fonts
clear hierarchy

Goal

Executive dashboards must look
like board decision tools
not developer dashboards.
